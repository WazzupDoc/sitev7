import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight } from "lucide-react";
import { ServiceIndex } from "@/components/site/ServiceIndex";
import { PageHero, QuoteSection } from "@/components/site/blocks";
import { events, images } from "@/data/site";
import { breadcrumbLd, pageHead } from "@/lib/seo";

export const Route = createFileRoute("/servicii")({
  head: () =>
    pageHead({
      title: "Servicii pentru evenimente: DJ, trupă, sonorizare, lumini | Green Sound Music",
      description:
        "DJ & MC, trupă live, sonorizare, lumini, ecrane LED, fum greu, hostess, ursitoare, Start Veselia și studio de înregistrări — toate de la Green Sound Music, Pitești.",
      path: "/servicii",
      jsonLd: [
        breadcrumbLd([
          { name: "Acasă", path: "/" },
          { name: "Servicii", path: "/servicii" },
        ]),
      ],
    }),
  component: Page,
});

function Page() {
  return (
    <>
      <PageHero
        eyebrow="Servicii / o singură echipă"
        title="Muzică, tehnică și efecte construite ca o singură producție"
        lead="Rezervă un serviciu sau combină-le. Planificarea rămâne clară, iar echipa tehnică și artiștii lucrează după același fir al evenimentului."
        image={images.scena}
        crumbs={[{ name: "Acasă", to: "/" }, { name: "Servicii" }]}
      />

      <section className="section surface-paper">
        <div className="container-site">
          <div className="mb-12 max-w-3xl">
            <p className="eyebrow">Index complet</p>
            <h2 className="display-lg mt-5">
              Alege punctul de plecare.{" "}
              <span className="serif-accent">Noi te ajutăm cu restul.</span>
            </h2>
          </div>
          <ServiceIndex />
        </div>
      </section>

      <section className="section" aria-labelledby="services-events">
        <div className="container-site grid gap-10 lg:grid-cols-12">
          <div className="lg:col-span-4">
            <p className="eyebrow">Nu știi ce serviciu?</p>
            <h2 id="services-events" className="display-lg mt-5">
              Începe de la tipul evenimentului.
            </h2>
          </div>
          <ul className="border-t border-border lg:col-span-7 lg:col-start-6">
            {events.map((event) => (
              <li key={event.slug} className="border-b border-border">
                <Link
                  to="/evenimente/$slug"
                  params={{ slug: event.slug }}
                  className="group flex items-center justify-between gap-5 py-6"
                >
                  <span>
                    <span className="block font-display text-xl font-semibold">{event.name}</span>
                    <span className="mt-1 block text-sm text-muted-foreground">{event.short}</span>
                  </span>
                  <ArrowRight
                    className="size-5 shrink-0 text-primary transition-transform group-hover:translate-x-1"
                    aria-hidden
                  />
                </Link>
              </li>
            ))}
          </ul>
        </div>
      </section>

      <QuoteSection />
    </>
  );
}
