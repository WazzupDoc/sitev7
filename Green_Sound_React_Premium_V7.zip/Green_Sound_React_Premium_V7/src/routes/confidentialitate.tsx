import { createFileRoute, Link } from "@tanstack/react-router";
import { business } from "@/data/site";
import { breadcrumbLd, pageHead } from "@/lib/seo";

export const Route = createFileRoute("/confidentialitate")({
  head: () =>
    pageHead({
      title: "Politica de confidențialitate | Green Sound Music",
      description:
        "Informații despre datele introduse în formularul de ofertă Green Sound Music și canalele externe WhatsApp și email.",
      path: "/confidentialitate",
      jsonLd: [
        breadcrumbLd([
          { name: "Acasă", path: "/" },
          { name: "Confidențialitate", path: "/confidentialitate" },
        ]),
      ],
    }),
  component: Page,
});

function Page() {
  return (
    <article className="container-site max-w-4xl pb-24 pt-32 md:pt-40">
      <p className="eyebrow">Informații legale</p>
      <h1 className="display-xl mt-6">Politica de confidențialitate</h1>
      <p className="mt-6 text-muted-foreground">Ultima actualizare: 2026</p>

      <div className="prose-site mt-12 space-y-10 text-base leading-relaxed text-foreground/78">
        <section>
          <h2 className="display-md">Cum funcționează formularul</h2>
          <p className="mt-4">
            Formularul de ofertă validează informațiile introduse și pregătește un mesaj pentru
            WhatsApp sau email. Site-ul nu salvează și nu trimite automat formularul către un server
            Green Sound Music. Mesajul ajunge la noi numai după ce confirmi trimiterea în aplicația
            WhatsApp sau în aplicația ta de email.
          </p>
        </section>
        <section>
          <h2 className="display-md">Datele folosite</h2>
          <p className="mt-4">
            Mesajul poate include numele, telefonul, emailul, tipul și data evenimentului, locația,
            numărul aproximativ de invitați, serviciile alese și detaliile pe care decizi să le
            introduci. Aceste informații sunt folosite pentru a răspunde solicitării tale.
          </p>
        </section>
        <section>
          <h2 className="display-md">Servicii externe</h2>
          <p className="mt-4">
            WhatsApp, furnizorul aplicației tale de email și YouTube pot prelucra date conform
            propriilor politici. Videoclipurile YouTube de pe site sunt încărcate doar după ce apeși
            butonul de redare și folosesc domeniul youtube-nocookie.com.
          </p>
        </section>
        <section>
          <h2 className="display-md">Contact</h2>
          <p className="mt-4">
            Pentru întrebări privind datele tale, scrie la{" "}
            <a
              className="text-primary underline underline-offset-4"
              href={`mailto:${business.email}`}
            >
              {business.email}
            </a>{" "}
            sau folosește pagina de{" "}
            <Link to="/contact" className="text-primary underline underline-offset-4">
              contact
            </Link>
            .
          </p>
        </section>
      </div>
    </article>
  );
}
