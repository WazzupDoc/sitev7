import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { ProjectRail } from "@/components/site/ProjectRail";
import { QuoteSection } from "@/components/site/blocks";
import { VideoLite } from "@/components/site/VideoLite";
import { images, mediaLibrary, videos } from "@/data/site";
import { breadcrumbLd, pageHead } from "@/lib/seo";

export const Route = createFileRoute("/portofoliu")({
  head: () =>
    pageHead({
      title: "Portofoliu video și foto — nunți, show de lumini, studio | Green Sound Music",
      description:
        "Filmări și fotografii reale Green Sound Music: nunta de la Ramada Pitești, show de lumini, fum greu, producții de studio și apariția TV la Neatza.",
      path: "/portofoliu",
      jsonLd: [
        breadcrumbLd([
          { name: "Acasă", path: "/" },
          { name: "Portofoliu", path: "/portofoliu" },
        ]),
      ],
    }),
  component: Page,
});

const filters = [
  { id: "toate", label: "Toate" },
  { id: "nunti", label: "Nunți" },
  { id: "dj-mc", label: "DJ & MC" },
  { id: "sonorizare", label: "Sunet & lumini" },
  { id: "fum-greu", label: "Efecte" },
  { id: "studio", label: "Studio" },
  { id: "copii-hostess", label: "Momente speciale" },
];

function Page() {
  const [active, setActive] = useState("toate");
  const items = useMemo(
    () =>
      active === "toate" ? mediaLibrary : mediaLibrary.filter((item) => item.tags.includes(active)),
    [active],
  );

  return (
    <>
      <section className="border-b border-border pb-16 pt-28 md:pb-24 md:pt-36">
        <div className="container-site">
          <p className="eyebrow">Portofoliu / material autentic</p>
          <div className="mt-6 grid gap-10 lg:grid-cols-12 lg:items-end">
            <h1 className="display-xl max-w-5xl lg:col-span-8">
              Evenimente și producții reale,{" "}
              <span className="serif-accent text-primary">nu imagini de catalog.</span>
            </h1>
            <p className="lead text-foreground/70 lg:col-span-4">
              O selecție din filmările și fotografiile Green Sound Music. Fiecare material poate fi
              deschis, redat și navigat.
            </p>
          </div>
        </div>
      </section>

      <section className="section surface-paper" aria-labelledby="featured-work">
        <div className="container-site grid gap-10 lg:grid-cols-12 lg:items-end">
          <div className="lg:col-span-9" data-reveal="mask">
            <VideoLite
              video={videos.nuntaRamada}
              priority
              className="[&_figcaption]:text-paper-muted"
            />
          </div>
          <div className="lg:col-span-3">
            <p className="label-tech text-paper-muted">Selecția 01 / Nuntă</p>
            <h2 id="featured-work" className="mt-4 font-display text-3xl font-semibold">
              DJ Green Sound & MC Dana
            </h2>
            <p className="mt-4 text-sm leading-relaxed text-paper-muted">
              Material real de la o nuntă din Pitești. Filmarea pornește doar după apăsarea
              butonului play.
            </p>
          </div>
        </div>
      </section>

      <section className="section overflow-hidden" aria-labelledby="work-index">
        <div className="container-site mb-10">
          <div className="grid gap-8 lg:grid-cols-12 lg:items-end">
            <div className="lg:col-span-6">
              <p className="eyebrow">Index de lucru</p>
              <h2 id="work-index" className="display-lg mt-5">
                Navighează arhiva.
              </h2>
            </div>
            <div
              role="group"
              aria-label="Filtrează portofoliul"
              className="no-scrollbar flex gap-2 overflow-x-auto pb-2 lg:col-span-6 lg:justify-end"
            >
              {filters.map((filter) => (
                <button
                  key={filter.id}
                  type="button"
                  aria-pressed={active === filter.id}
                  onClick={() => setActive(filter.id)}
                  className={`shrink-0 rounded-full border px-4 py-2 text-sm transition-colors ${
                    active === filter.id
                      ? "border-primary bg-primary text-primary-foreground"
                      : "border-border text-foreground/75 hover:border-foreground/45"
                  }`}
                >
                  {filter.label}
                </button>
              ))}
            </div>
          </div>
          <p className="mt-5 text-sm text-muted-foreground" aria-live="polite">
            {items.length} materiale în selecția curentă
          </p>
        </div>
        <ProjectRail key={active} items={items} label={`Portofoliu: ${active}`} />
      </section>

      <section className="section border-t border-border">
        <div className="container-site grid gap-5 sm:grid-cols-2">
          {[images.scena, images.concert].map((image, index) => (
            <figure key={image.src} className={index === 1 ? "sm:mt-20" : ""} data-reveal="mask">
              <img
                src={image.src}
                alt={image.alt}
                width={image.w}
                height={image.h}
                loading="lazy"
                decoding="async"
                className="aspect-[4/5] w-full object-cover sm:aspect-[4/3]"
              />
              <figcaption className="label-tech mt-3 text-foreground/45">
                Green Sound archive / {String(index + 1).padStart(2, "0")}
              </figcaption>
            </figure>
          ))}
        </div>
      </section>

      <QuoteSection title="Construim următorul moment împreună?" />
    </>
  );
}
