import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, ArrowUpRight, Phone } from "lucide-react";
import type { CSSProperties } from "react";
import { FaqList, QuoteSection, SectionHeading } from "@/components/site/blocks";
import { ProjectRail } from "@/components/site/ProjectRail";
import { EventSelector } from "@/components/site/EventSelector";
import { ServiceIndex } from "@/components/site/ServiceIndex";
import { VideoLite } from "@/components/site/VideoLite";
import { Button } from "@/components/ui/button";
import {
  business,
  generalFaqs,
  images,
  mediaLibrary,
  people,
  process,
  rider,
  videos,
} from "@/data/site";
import { faqLd, localBusinessLd, pageHead } from "@/lib/seo";

const yearsActive = new Date().getFullYear() - business.founded;
const pad = (value: number) => String(value).padStart(2, "0");

export const Route = createFileRoute("/")({
  head: () =>
    pageHead({
      title: "Green Sound Music Pitești — DJ, trupă live, sonorizare și lumini pentru evenimente",
      description:
        "Din 2008, în Pitești: DJ & MC, trupă live, sonorizare, lumini, ecrane LED, fum greu, hostess, ursitoare și studio de înregistrări. Cere o ofertă pentru evenimentul tău.",
      path: "/",
      jsonLd: [localBusinessLd(), faqLd(generalFaqs)],
    }),
  component: Index,
});

function Index() {
  return (
    <>
      <section className="hero-composition relative isolate overflow-hidden border-b border-border pt-28 sm:pt-32">
        <div className="container-site grid min-h-[calc(100svh-7rem)] items-center gap-14 pb-14 lg:grid-cols-12 lg:gap-8 lg:pb-20">
          <div className="relative z-10 lg:col-span-5 lg:pb-10">
            <p className="hero-kicker label-tech animate-rise text-primary">
              Pitești · producție de evenimente · din {business.founded}
            </p>
            <h1 className="hero-title mt-6 animate-rise [animation-delay:80ms]">
              Atmosfera nu se întâmplă{" "}
              <span className="serif-accent text-primary">întâmplător.</span>
            </h1>
            <p className="lead mt-7 max-w-lg animate-rise text-foreground/72 [animation-delay:150ms]">
              Muzică live, DJ & MC, sunet și lumini — coordonate pentru evenimentul tău de aceeași
              echipă.
            </p>
            <div className="mt-9 flex flex-wrap gap-3 animate-rise [animation-delay:220ms]">
              <Button asChild variant="hero" size="xl">
                <Link data-magnetic to="/portofoliu">
                  Descoperă proiectele <ArrowRight aria-hidden />
                </Link>
              </Button>
              <Button asChild variant="stage" size="xl">
                <Link data-magnetic to="/contact">Cere ofertă</Link>
              </Button>
            </div>
            <div
              className="mt-10 overflow-hidden border border-border sm:hidden"
              data-reveal="mask"
            >
              <img
                src={images.concert.src}
                alt={images.concert.alt}
                width={images.concert.w}
                height={images.concert.h}
                fetchPriority="high"
                className="aspect-[16/10] w-full object-cover"
              />
            </div>
            <div className="mt-12 grid max-w-lg grid-cols-2 gap-5 border-t border-border pt-5 text-sm text-muted-foreground sm:grid-cols-3">
              <p>
                <span className="block font-display text-xl font-semibold text-foreground">
                  {yearsActive}+
                </span>
                ani de activitate
              </p>
              <p>
                <span className="block font-display text-xl font-semibold text-foreground">
                  01 echipă
                </span>
                muzică + tehnică
              </p>
              <p className="col-span-2 sm:col-span-1">
                <span className="block font-display text-xl font-semibold text-foreground">
                  Argeș
                </span>
                disponibilitate la cerere
              </p>
            </div>
          </div>

          <div className="relative mx-auto hidden w-full max-w-2xl sm:block lg:col-span-7 lg:max-w-none">
            <div
              data-reveal="mask"
              data-parallax
              data-parallax-strength="36"
              className="hero-main-frame relative ml-auto aspect-[4/5] w-[82%] overflow-hidden bg-card sm:aspect-[5/6] lg:w-[76%]"
            >
              <img
                src={images.scena.src}
                alt={images.scena.alt}
                width={images.scena.w}
                height={images.scena.h}
                fetchPriority="high"
                data-parallax-image
                className="size-full object-cover object-[50%_38%]"
              />
              <div className="absolute inset-0 bg-ink/10" />
              <p className="label-tech absolute left-5 top-5 border border-foreground/25 bg-ink/65 px-3 py-2 text-foreground/85 backdrop-blur-sm">
                Live production / 01
              </p>
            </div>
            <div
              data-reveal
              style={{ "--d": "180ms" } as CSSProperties}
              className="absolute bottom-[8%] left-0 w-[48%] overflow-hidden border-[6px] border-background bg-card shadow-card sm:border-[10px]"
            >
              <img
                src={images.concert.src}
                alt={images.concert.alt}
                width={images.concert.w}
                height={images.concert.h}
                loading="lazy"
                decoding="async"
                fetchPriority="low"
                className="aspect-[4/3] w-full object-cover"
              />
            </div>
            <div className="absolute -right-1 bottom-[5%] hidden w-52 border-l border-border pl-5 lg:block">
              <p className="label-tech text-primary">The craft behind the moment</p>
              <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
                Artiști, operatori și tehnică într-un singur plan pentru seară.
              </p>
            </div>
            <p className="label-tech absolute right-[3%] top-[10%] [writing-mode:vertical-rl] text-foreground/35">
              GS — LIVE / {new Date().getFullYear()}
            </p>
          </div>
        </div>
      </section>

      <section className="section surface-paper" aria-labelledby="proof-title">
        <div className="container-site">
          <div className="grid gap-10 lg:grid-cols-12 lg:items-end">
            <div className="lg:col-span-7">
              <p className="eyebrow">Proiect real · Nuntă</p>
              <h2 id="proof-title" className="display-lg mt-5 max-w-3xl">
                Înainte de promisiuni,{" "}
                <span className="serif-accent">vezi atmosfera pe care o construim.</span>
              </h2>
            </div>
            <div className="lg:col-span-4 lg:col-start-9">
              <p className="text-base leading-relaxed text-paper-muted">
                DJ Green Sound și MC Dana la o nuntă din Pitești. Filmarea pornește doar la alegerea
                ta.
              </p>
            </div>
          </div>
          <div className="mt-12 grid gap-8 lg:grid-cols-12 lg:items-end">
            <div className="lg:col-span-9" data-reveal="mask">
              <VideoLite
                video={videos.nuntaRamada}
                priority
                className="[&_figcaption]:text-paper-muted"
              />
            </div>
            <dl className="grid grid-cols-2 gap-px border border-paper-border bg-paper-border lg:col-span-3 lg:grid-cols-1">
              {[
                ["Rol", "DJ & MC"],
                ["Format", "Nuntă"],
                ["Material", "Video real"],
                ["Acțiune", "Click pentru redare"],
              ].map(([term, value]) => (
                <div key={term} className="bg-paper p-5">
                  <dt className="label-tech text-paper-muted">{term}</dt>
                  <dd className="mt-2 font-display text-lg font-semibold">{value}</dd>
                </div>
              ))}
            </dl>
          </div>
        </div>
      </section>

      <section className="section overflow-hidden" aria-labelledby="archive-title">
        <div className="container-site mb-12 flex flex-col justify-between gap-7 md:flex-row md:items-end">
          <SectionHeading
            eyebrow="Arhivă de lucru"
            title={
              <span id="archive-title">
                Momente reale.{" "}
                <span className="serif-accent text-primary">Perspective diferite.</span>
              </span>
            }
            intro="Glisează, folosește săgețile sau tastele. Fiecare cadru deschide fotografia ori filmarea originală."
          />
          <Link
            to="/portofoliu"
            className="inline-flex items-center gap-2 text-sm font-semibold text-primary"
          >
            Vezi portofoliul complet <ArrowRight className="size-4" aria-hidden />
          </Link>
        </div>
        <ProjectRail
          items={mediaLibrary.slice(0, 8)}
          label="Selecție din portofoliul Green Sound"
        />
      </section>

      <section className="section surface-paper" aria-labelledby="services-title">
        <div className="container-site">
          <div className="mb-12 grid gap-8 lg:grid-cols-12">
            <div className="lg:col-span-7">
              <p className="eyebrow">Servicii coordonate</p>
              <h2 id="services-title" className="display-lg mt-5">
                Tot ce se aude și se vede,{" "}
                <span className="serif-accent">fără opt furnizori de coordonat.</span>
              </h2>
            </div>
            <p className="self-end text-paper-muted lg:col-span-4 lg:col-start-9">
              Fiecare serviciu poate fi rezervat separat. Împreună, ele funcționează ca o singură
              producție.
            </p>
          </div>
          <ServiceIndex />
        </div>
      </section>

      {/* Premium event navigator: touch-first, photographic, with contextual services. */}
      <section className="section" aria-labelledby="events-title">
        <div className="container-site">
          <div className="mb-12 grid gap-8 lg:grid-cols-12 lg:items-end">
            <div className="lg:col-span-7">
              <p className="eyebrow">Evenimentul tău, în prim-plan</p>
              <h2 id="events-title" className="display-lg mt-5 max-w-3xl">
                Atmosfera începe cu <span className="serif-accent text-primary">o alegere.</span>
              </h2>
            </div>
            <div className="lg:col-span-4 lg:col-start-9">
              <p className="text-base leading-relaxed text-muted-foreground">
                Descoperă opțiunile pentru fiecare tip de eveniment. Fotografiile și recomandările
                se schimbă când alegi categoria.
              </p>
            </div>
          </div>
          <EventSelector />
        </div>
      </section>

      <section
        className="surface-paper border-y border-paper-border"
        aria-labelledby="capability-title"
      >
        <div className="container-site grid lg:grid-cols-12">
          <div className="py-16 lg:col-span-5 lg:py-24 lg:pr-16">
            <p className="eyebrow">Capabilități reale</p>
            <h2 id="capability-title" className="display-lg mt-5">
              De la sala goală la <span className="serif-accent">primul sunet.</span>
            </h2>
            <p className="mt-6 max-w-md text-paper-muted">
              Montaj, probe, operare și echipamente verificate înainte de fiecare eveniment.
            </p>
            <Button asChild variant="paperOutline" size="xl" className="mt-9">
              <Link to="/echipamente-de-sunet-si-lumini">Vezi partea tehnică</Link>
            </Button>
          </div>
          <div className="border-t border-paper-border py-10 lg:col-span-7 lg:border-l lg:border-t-0 lg:py-16 lg:pl-12">
            {rider.map((group, index) => (
              <div
                key={group.area}
                className="grid gap-3 border-b border-paper-border py-5 first:pt-0 sm:grid-cols-[3rem_8rem_1fr]"
              >
                <span className="label-tech text-paper-muted">{pad(index + 1)}</span>
                <h3 className="font-display text-lg font-semibold">{group.area}</h3>
                <p className="text-sm leading-relaxed text-paper-muted">
                  {group.items.join(" · ")}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="section" aria-labelledby="people-title">
        <div className="container-site grid gap-14 lg:grid-cols-12">
          <div className="lg:col-span-5">
            <div data-reveal="mask" data-parallax data-parallax-strength="24" className="gs-parallax-aspect relative aspect-[4/5] overflow-hidden">
              <img
                src={images.dj.src}
                alt={images.dj.alt}
                width={images.dj.w}
                height={images.dj.h}
                loading="lazy"
                decoding="async"
                data-parallax-image
                className="aspect-[4/5] w-full object-cover"
              />
              <p className="label-tech absolute bottom-5 left-5 bg-ink/75 px-3 py-2 text-foreground/80 backdrop-blur-sm">
                Echipa Green Sound / în eveniment
              </p>
            </div>
          </div>
          <div className="lg:col-span-6 lg:col-start-7">
            <p className="eyebrow">Oamenii din spatele scenei</p>
            <h2 id="people-title" className="display-lg mt-5">
              Tehnica ajută.{" "}
              <span className="serif-accent text-primary">Oamenii fac seara să curgă.</span>
            </h2>
            <ul className="mt-10 border-t border-border">
              {people.map((person, index) => (
                <li
                  key={person.name}
                  className="grid grid-cols-[2.5rem_1fr] gap-3 border-b border-border py-5 sm:grid-cols-[3rem_1fr_1fr]"
                >
                  <span className="label-tech text-foreground/35">{pad(index + 1)}</span>
                  <p className="font-display text-lg font-semibold">{person.name}</p>
                  <p className="col-start-2 text-sm text-muted-foreground sm:col-start-auto">
                    {person.role}
                  </p>
                </li>
              ))}
            </ul>
            <Link
              to="/despre-noi"
              className="mt-8 inline-flex items-center gap-2 text-sm font-semibold text-primary"
            >
              Povestea și procesul nostru <ArrowRight className="size-4" aria-hidden />
            </Link>
          </div>
        </div>

        <div className="container-site mt-20">
          <ol className="grid border-y border-border md:grid-cols-4">
            {process.map((step, index) => (
              <li
                key={step.title}
                className="border-b border-border py-7 md:border-b-0 md:border-r md:px-7 md:last:border-r-0 md:first:pl-0"
              >
                <span className="label-tech text-primary">Cue {pad(index + 1)}</span>
                <h3 className="mt-5 font-display text-xl font-semibold">{step.title}</h3>
                <p className="mt-3 text-sm leading-relaxed text-muted-foreground">{step.text}</p>
              </li>
            ))}
          </ol>
        </div>
      </section>

      <section className="section border-t border-border" aria-labelledby="faq-title">
        <div className="container-site grid gap-12 lg:grid-cols-12">
          <div className="lg:col-span-4">
            <p className="eyebrow">Întrebări frecvente</p>
            <h2 id="faq-title" className="display-lg mt-5">
              Clar înainte de <span className="serif-accent text-primary">prima discuție.</span>
            </h2>
            <a
              href={business.phoneHref}
              className="mt-8 inline-flex items-center gap-2 text-sm font-semibold text-foreground"
            >
              <Phone className="size-4 text-primary" aria-hidden /> {business.phoneDisplay}
            </a>
          </div>
          <div className="lg:col-span-7 lg:col-start-6">
            <FaqList faqs={generalFaqs} />
          </div>
        </div>
      </section>

      <QuoteSection />
    </>
  );
}
