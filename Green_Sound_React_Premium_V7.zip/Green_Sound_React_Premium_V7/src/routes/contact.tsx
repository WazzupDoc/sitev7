import { createFileRoute } from "@tanstack/react-router";
import { Mail, MapPin, MessageCircle, Phone } from "lucide-react";
import { QuoteSection } from "@/components/site/blocks";
import { business } from "@/data/site";
import { defaultWhatsappText, whatsappUrl } from "@/lib/quote";
import { breadcrumbLd, pageHead } from "@/lib/seo";

export const Route = createFileRoute("/contact")({
  head: () =>
    pageHead({
      title: "Contact și cerere de ofertă | Green Sound Music Pitești",
      description:
        "Spune-ne data, locația și tipul evenimentului. Contactează Green Sound Music prin telefon, WhatsApp sau email pentru o ofertă personalizată.",
      path: "/contact",
      jsonLd: [
        breadcrumbLd([
          { name: "Acasă", path: "/" },
          { name: "Contact", path: "/contact" },
        ]),
      ],
    }),
  component: Page,
});

const channels = [
  {
    label: "Telefon",
    value: business.phoneDisplay,
    href: business.phoneHref,
    icon: Phone,
  },
  {
    label: "WhatsApp",
    value: "Deschide conversația",
    href: whatsappUrl(defaultWhatsappText),
    icon: MessageCircle,
    external: true,
  },
  {
    label: "Email",
    value: business.email,
    href: `mailto:${business.email}`,
    icon: Mail,
  },
];

function Page() {
  return (
    <>
      <section className="border-b border-border pb-16 pt-28 md:pb-24 md:pt-36">
        <div className="container-site grid gap-12 lg:grid-cols-12 lg:items-end">
          <div className="lg:col-span-7">
            <p className="eyebrow">Contact / ofertă</p>
            <h1 className="display-xl mt-6">
              Spune-ne data. <span className="serif-accent text-primary">Începem de acolo.</span>
            </h1>
          </div>
          <p className="lead text-foreground/70 lg:col-span-4 lg:col-start-9">
            Pentru o ofertă utilă avem nevoie de tipul evenimentului, locație și serviciile care te
            interesează.
          </p>
        </div>
      </section>

      <section className="section surface-paper">
        <div className="container-site grid gap-px border border-paper-border bg-paper-border md:grid-cols-3">
          {channels.map(({ label, value, href, icon: Icon, external }) => (
            <a
              key={label}
              href={href}
              target={external ? "_blank" : undefined}
              rel={external ? "noopener noreferrer" : undefined}
              className="group bg-paper p-7 transition-colors hover:bg-white"
            >
              <Icon className="size-5 text-primary" aria-hidden />
              <p className="label-tech mt-8 text-paper-muted">{label}</p>
              <p className="mt-2 font-display text-xl font-semibold">{value}</p>
            </a>
          ))}
        </div>
        <div className="container-site mt-10 flex items-start gap-3 text-paper-muted">
          <MapPin className="mt-0.5 size-5 shrink-0 text-primary" aria-hidden />
          <address className="not-italic">
            {business.address.street}, {business.address.city}, jud. {business.address.region}
          </address>
        </div>
      </section>

      <QuoteSection
        title="Pregătește cererea pentru WhatsApp sau email."
        intro="Formularul validează detaliile și pregătește mesajul. La final, tu apeși Trimite în WhatsApp sau în aplicația de email; datele nu sunt expediate automat de site."
      />
    </>
  );
}
