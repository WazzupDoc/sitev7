import { createFileRoute } from "@tanstack/react-router";
import { PageHero, QuoteSection } from "@/components/site/blocks";
import { business, images, people, process, rider } from "@/data/site";
import { breadcrumbLd, pageHead } from "@/lib/seo";

export const Route = createFileRoute("/despre-noi")({
  head: () =>
    pageHead({
      title: "Despre Green Sound Music — echipa din spatele evenimentului",
      description:
        "Green Sound Music este o echipă din Pitești activă din 2008, pentru DJ & MC, trupă live, sonorizare, lumini, efecte și producție muzicală.",
      path: "/despre-noi",
      jsonLd: [
        breadcrumbLd([
          { name: "Acasă", path: "/" },
          { name: "Despre noi", path: "/despre-noi" },
        ]),
      ],
    }),
  component: Page,
});

function Page() {
  return (
    <>
      <PageHero
        eyebrow={`Despre noi / din ${business.founded}`}
        title="Echipa care leagă scena, sunetul și oamenii"
        lead="Green Sound Music lucrează la intersecția dintre partea artistică și producția tehnică. Un singur plan pentru artiști, echipamente și momentele serii."
        image={images.dj}
        crumbs={[{ name: "Acasă", to: "/" }, { name: "Despre noi" }]}
      />

      <section className="section surface-paper">
        <div className="container-site grid gap-14 lg:grid-cols-12">
          <div className="lg:col-span-5">
            <p className="eyebrow">Ce facem</p>
            <h2 className="display-lg mt-5">
              Meșteșugul din spatele <span className="serif-accent">momentului live.</span>
            </h2>
          </div>
          <div className="space-y-6 text-lg leading-relaxed text-paper-muted lg:col-span-6 lg:col-start-7">
            <p>
              Din 2008, Green Sound Music oferă servicii artistice și tehnice pentru nunți,
              botezuri, evenimente corporate, petreceri, concerte și festivaluri.
            </p>
            <p>
              Echipa reunește DJ, MC, muzicieni și operatori tehnici. Studioul de înregistrări,
              fondat în 2009, completează activitatea de scenă cu producție muzicală.
            </p>
          </div>
        </div>
      </section>

      <section className="section">
        <div className="container-site grid gap-12 lg:grid-cols-12">
          <div className="lg:col-span-4">
            <p className="eyebrow">Oameni</p>
            <h2 className="display-lg mt-5">Roluri clare, aceeași echipă.</h2>
          </div>
          <ul className="border-t border-border lg:col-span-7 lg:col-start-6">
            {people.map((person, index) => (
              <li
                key={person.name}
                className="grid grid-cols-[3rem_1fr] gap-3 border-b border-border py-6 sm:grid-cols-[3rem_1fr_1fr]"
              >
                <span className="label-tech text-primary">
                  {String(index + 1).padStart(2, "0")}
                </span>
                <p className="font-display text-xl font-semibold">{person.name}</p>
                <p className="col-start-2 text-muted-foreground sm:col-start-auto">{person.role}</p>
              </li>
            ))}
          </ul>
        </div>
      </section>

      <section className="section surface-paper">
        <div className="container-site">
          <p className="eyebrow">Proces</p>
          <h2 className="display-lg mt-5 max-w-3xl">
            De la primul mesaj la <span className="serif-accent">montaj și operare.</span>
          </h2>
          <ol className="mt-12 grid gap-px border border-paper-border bg-paper-border md:grid-cols-4">
            {process.map((step, index) => (
              <li key={step.title} className="bg-paper p-7">
                <span className="label-tech text-primary">
                  Cue {String(index + 1).padStart(2, "0")}
                </span>
                <h3 className="mt-6 font-display text-xl font-semibold">{step.title}</h3>
                <p className="mt-3 text-sm leading-relaxed text-paper-muted">{step.text}</p>
              </li>
            ))}
          </ol>
          <p className="label-tech mt-12 text-paper-muted">Rider / capabilități</p>
          <div className="mt-4 grid gap-5 md:grid-cols-2 lg:grid-cols-5">
            {rider.map((group) => (
              <div key={group.area} className="border-t border-paper-border pt-4">
                <h3 className="font-display text-lg font-semibold">{group.area}</h3>
                <p className="mt-2 text-sm leading-relaxed text-paper-muted">
                  {group.items.join(" · ")}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <QuoteSection />
    </>
  );
}
