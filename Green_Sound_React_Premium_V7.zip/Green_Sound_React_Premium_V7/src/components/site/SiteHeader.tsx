import { Link, useRouterState } from "@tanstack/react-router";
import { ArrowUpRight, Menu, Phone, X } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { business, navEvents, navServices } from "@/data/site";
import { Logo } from "./Logo";

const primaryLinks = [
  { to: "/evenimente", label: "Evenimente" },
  { to: "/servicii", label: "Servicii" },
  { to: "/portofoliu", label: "Portofoliu" },
  { to: "/despre-noi", label: "Despre noi" },
];

export function SiteHeader() {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const menuButton = useRef<HTMLButtonElement>(null);
  const panel = useRef<HTMLDivElement>(null);
  const pathname = useRouterState({ select: (state) => state.location.pathname });

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    setMobileOpen(false);
  }, [pathname]);

  useEffect(() => {
    if (!mobileOpen) return;
    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    panel.current?.querySelector<HTMLElement>("a, button")?.focus();

    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape") {
        setMobileOpen(false);
        menuButton.current?.focus();
        return;
      }
      if (event.key !== "Tab" || !panel.current) return;
      const focusable = Array.from(
        panel.current.querySelectorAll<HTMLElement>(
          'a[href], button:not([disabled]), [tabindex="0"]',
        ),
      );
      const first = focusable[0];
      const last = focusable[focusable.length - 1];
      if (!first || !last) return;
      if (event.shiftKey && document.activeElement === first) {
        event.preventDefault();
        last.focus();
      } else if (!event.shiftKey && document.activeElement === last) {
        event.preventDefault();
        first.focus();
      }
    };

    document.addEventListener("keydown", onKeyDown);
    return () => {
      document.body.style.overflow = previousOverflow;
      document.removeEventListener("keydown", onKeyDown);
    };
  }, [mobileOpen]);

  return (
    <header
      className={`fixed inset-x-0 top-0 z-40 transition-colors duration-300 ${
        scrolled || mobileOpen
          ? "border-b border-border bg-background/94 backdrop-blur-xl"
          : "bg-background/15"
      }`}
    >
      <a
        href="#continut"
        className="sr-only focus:not-sr-only focus:absolute focus:left-4 focus:top-4 focus:z-50 focus:bg-primary focus:px-4 focus:py-2 focus:text-primary-foreground"
      >
        Sari la conținut
      </a>
      <div className="container-site flex h-[4.75rem] items-center justify-between gap-6">
        <Logo />

        <nav aria-label="Navigare principală" className="hidden items-center gap-8 lg:flex">
          {primaryLinks.map((item) => (
            <Link
              key={item.to}
              data-magnetic
              to={item.to}
              className="link-underline text-sm font-medium text-foreground/72 transition-colors hover:text-foreground"
              activeProps={{ className: "text-foreground" }}
            >
              {item.label}
            </Link>
          ))}
        </nav>

        <div className="flex items-center gap-3">
          <a
            href={business.phoneHref}
            className="hidden items-center gap-2 text-sm font-semibold text-foreground xl:inline-flex"
          >
            <Phone className="size-4 text-primary" aria-hidden />
            {business.phoneDisplay}
          </a>
          <Link
            data-magnetic
            to="/contact"
            className="hidden items-center gap-2 rounded-full bg-primary px-5 py-3 text-sm font-semibold text-primary-foreground transition-transform duration-300 hover:-translate-y-0.5 sm:inline-flex"
          >
            Cere ofertă <ArrowUpRight className="size-4" aria-hidden />
          </Link>
          <button
            ref={menuButton}
            type="button"
            className="grid size-11 place-items-center rounded-full border border-border bg-background/60 lg:hidden"
            aria-label={mobileOpen ? "Închide meniul" : "Deschide meniul"}
            aria-expanded={mobileOpen}
            aria-controls="meniu-mobil"
            onClick={() => setMobileOpen((value) => !value)}
          >
            {mobileOpen ? (
              <X className="size-5" aria-hidden />
            ) : (
              <Menu className="size-5" aria-hidden />
            )}
          </button>
        </div>
      </div>

      {mobileOpen && (
        <div
          ref={panel}
          id="meniu-mobil"
          role="dialog"
          aria-modal="true"
          aria-label="Meniu principal"
          className="h-[calc(100dvh-4.75rem)] overflow-y-auto border-t border-border bg-background lg:hidden"
        >
          <nav className="container-site grid min-h-full content-between gap-12 py-8 pb-28">
            <div>
              <p className="label-tech text-primary">Navigare</p>
              <ul className="mt-5 border-t border-border">
                {primaryLinks.map((item, index) => (
                  <li key={item.to} className="border-b border-border">
                    <Link
                      to={item.to}
                      className="grid grid-cols-[2.5rem_1fr_auto] items-center py-4 font-display text-2xl font-semibold"
                    >
                      <span className="label-tech text-foreground/35">
                        {String(index + 1).padStart(2, "0")}
                      </span>
                      {item.label}
                      <ArrowUpRight className="size-5 text-primary" aria-hidden />
                    </Link>
                  </li>
                ))}
              </ul>
            </div>

            <div className="grid gap-8 sm:grid-cols-2">
              <div>
                <p className="label-tech text-foreground/45">Evenimente</p>
                <ul className="mt-3 grid gap-2 text-sm">
                  {navEvents.map((item) => (
                    <li key={item.to}>
                      <Link to={item.to} className="text-foreground/78">
                        {item.label}
                      </Link>
                    </li>
                  ))}
                </ul>
              </div>
              <div>
                <p className="label-tech text-foreground/45">Servicii</p>
                <ul className="mt-3 grid gap-2 text-sm">
                  {navServices.slice(0, 5).map((item) => (
                    <li key={item.to}>
                      <Link to={item.to} className="text-foreground/78">
                        {item.label}
                      </Link>
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <a
                href={business.phoneHref}
                className="flex items-center justify-center gap-2 border border-border px-4 py-3 text-sm font-semibold"
              >
                <Phone className="size-4 text-primary" aria-hidden /> Sună
              </a>
              <Link
                to="/contact"
                className="flex items-center justify-center gap-2 bg-primary px-4 py-3 text-sm font-semibold text-primary-foreground"
              >
                Cere ofertă
              </Link>
            </div>
          </nav>
        </div>
      )}
    </header>
  );
}
