import { useRouterState } from "@tanstack/react-router";
import { useEffect } from "react";

/**
 * Single scroll listener and a single RAF for all parallax scenes.
 * The original image layout stays intact in SSR. On touch/reduced motion,
 * no listener is active and the images are rendered without transforms.
 * This works with swapped media in EventSelector because the host is stable.
 */
export function ParallaxMotion() {
  const pathname = useRouterState({ select: (state) => state.location.pathname });

  useEffect(() => {
    const media = window.matchMedia("(min-width: 768px) and (hover: hover) and (pointer: fine) and (prefers-reduced-motion: no-preference)");
    const saveData = window.matchMedia("(prefers-reduced-data: reduce)");
    let enabled = false;
    let frame = 0;
    let hosts: HTMLElement[] = [];
    let observer: MutationObserver | null = null;

    const paint = () => {
      frame = 0;
      if (!enabled) return;
      const vh = window.innerHeight;
      for (const host of hosts) {
        const rect = host.getBoundingClientRect();
        if (rect.bottom < -80 || rect.top > vh + 80) continue;
        const image = host.querySelector<HTMLElement>("[data-parallax-image]");
        if (!image) continue;
        const travel = Number(host.dataset.parallaxStrength ?? 28);
        const safeTravel = Number.isFinite(travel) ? Math.min(40, Math.max(0, travel)) : 28;
        const centered = (vh / 2 - (rect.top + rect.height / 2)) / ((vh + rect.height) / 2);
        const offset = Math.min(1, Math.max(-1, centered)) * safeTravel;
        image.style.setProperty("--gs-parallax-y", `${offset.toFixed(1)}px`);
      }
    };
    const schedule = () => {
      if (!frame) frame = requestAnimationFrame(paint);
    };
    const scan = () => {
      hosts = Array.from(document.querySelectorAll<HTMLElement>("[data-parallax]"));
      schedule();
    };
    const teardown = () => {
      if (!enabled) return;
      enabled = false;
      window.removeEventListener("scroll", schedule);
      window.removeEventListener("resize", scan);
      observer?.disconnect();
      observer = null;
      cancelAnimationFrame(frame);
      frame = 0;
      document.querySelectorAll<HTMLElement>("[data-parallax-image]").forEach((image) => {
        image.style.removeProperty("--gs-parallax-y");
      });
    };
    const sync = () => {
      if (!media.matches || saveData.matches) {
        teardown();
        return;
      }
      if (enabled) return;
      enabled = true;
      scan();
      window.addEventListener("scroll", schedule, { passive: true });
      window.addEventListener("resize", scan, { passive: true });
      // Re-scan if an interactive gallery changes its media element.
      observer = new MutationObserver(scan);
      observer.observe(document.querySelector("#continut") ?? document.body, {
        childList: true,
        subtree: true,
      });
    };

    sync();
    media.addEventListener("change", sync);
    saveData.addEventListener("change", sync);
    return () => {
      media.removeEventListener("change", sync);
      saveData.removeEventListener("change", sync);
      teardown();
    };
  }, [pathname]);

  return null;
}
