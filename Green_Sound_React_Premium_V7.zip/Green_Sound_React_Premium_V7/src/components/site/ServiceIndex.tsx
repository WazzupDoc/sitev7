import { Link } from "@tanstack/react-router";
import { ArrowUpRight } from "lucide-react";
import { useState } from "react";
import { services } from "@/data/site";

const pad = (value: number) => String(value).padStart(2, "0");

export function ServiceIndex() {
  const [active, setActive] = useState(0);
  const service = services[active] ?? services[0]!;

  return (
    <div className="grid gap-10 lg:grid-cols-[minmax(0,1.1fr)_minmax(20rem,0.7fr)] lg:gap-16">
      <ol className="border-t border-paper-border">
        {services.map((item, index) => (
          <li key={item.slug}>
            <Link
              to={`/${item.slug}`}
              onMouseEnter={() => setActive(index)}
              onFocus={() => setActive(index)}
              className="group grid grid-cols-[2.5rem_1fr_auto] items-start gap-3 border-b border-paper-border py-5 outline-none sm:grid-cols-[3.5rem_1fr_auto] sm:py-6"
            >
              <span className="label-tech pt-1 text-paper-muted">{pad(index + 1)}</span>
              <span>
                <span className="block font-display text-xl font-semibold leading-tight transition-transform duration-300 ease-out group-hover:translate-x-1 group-focus-visible:translate-x-1 sm:text-2xl">
                  {item.name}
                </span>
                <span className="mt-2 hidden max-w-xl text-sm leading-relaxed text-paper-muted sm:block">
                  {item.short}
                </span>
              </span>
              <ArrowUpRight
                className="mt-1 size-5 text-paper-muted transition-all duration-300 group-hover:-translate-y-0.5 group-hover:translate-x-0.5 group-hover:text-paper-foreground"
                aria-hidden
              />
            </Link>
          </li>
        ))}
      </ol>

      <div
        className="relative hidden min-h-[34rem] overflow-hidden bg-paper-foreground lg:block"
        aria-live="polite"
      >
        <img
          key={service.slug}
          src={service.image.src}
          alt={service.image.alt}
          width={service.image.w}
          height={service.image.h}
          loading="lazy"
          decoding="async"
          className="absolute inset-0 size-full animate-media-in object-cover"
        />
        <div className="scrim-bottom absolute inset-0" />
        <div className="absolute inset-x-0 bottom-0 flex items-end justify-between gap-6 p-7 text-foreground">
          <div>
            <p className="label-tech text-foreground/60">Serviciu activ</p>
            <p className="mt-2 max-w-sm font-display text-2xl font-semibold">{service.name}</p>
          </div>
          <span className="label-tech border-l border-foreground/20 pl-5 text-foreground/60">
            GS / {pad(active + 1)}
          </span>
        </div>
      </div>
    </div>
  );
}
