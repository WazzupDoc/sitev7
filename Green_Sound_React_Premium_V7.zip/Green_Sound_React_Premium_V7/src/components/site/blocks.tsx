import { Link } from "@tanstack/react-router";
import { ArrowUpRight, Phone } from "lucide-react";
import { lazy, Suspense, type ReactNode } from "react";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Button } from "@/components/ui/button";
import { business, type ImageRef, process } from "@/data/site";
import { ParallaxImage } from "./ParallaxImage";
import type { eventTypeOptions } from "@/lib/quote";

const QuoteForm = lazy(() =>
  import("./QuoteForm").then((module) => ({ default: module.QuoteForm })),
);

export function Breadcrumbs({ items }: { items: { name: string; to?: string }[] }) {
  return (
    <nav aria-label="Breadcrumb" className="text-sm text-foreground/70">
      <ol className="flex flex-wrap items-center gap-2">
        {items.map((it, i) => (
          <li key={it.name} className="flex items-center gap-2">
            {it.to ? (
              <Link to={it.to} className="link-underline hover:text-foreground">
                {it.name}
              </Link>
            ) : (
              <span aria-current="page" className="text-foreground">
                {it.name}
              </span>
            )}
            {i < items.length - 1 && (
              <span aria-hidden className="text-foreground/40">
                /
              </span>
            )}
          </li>
        ))}
      </ol>
    </nav>
  );
}

export function PageHero({
  eyebrow,
  title,
  lead,
  image,
  crumbs,
  children,
}: {
  eyebrow: string;
  title: string;
  lead: string;
  image: ImageRef;
  crumbs: { name: string; to?: string }[];
  children?: ReactNode;
}) {
  return (
    <section className="overflow-hidden border-b border-border pb-16 pt-28 md:pb-24 md:pt-36">
      <div className="container-site">
        <Breadcrumbs items={crumbs} />
        <div className="mt-10 grid gap-12 lg:grid-cols-12 lg:items-end">
          <div className="lg:col-span-7">
            <p className="eyebrow animate-rise">{eyebrow}</p>
            <h1 className="display-xl mt-6 max-w-5xl animate-rise [animation-delay:80ms]">
              {title}
            </h1>
            <p className="lead mt-6 max-w-2xl animate-rise text-foreground/75 [animation-delay:160ms]">
              {lead}
            </p>
            <div className="mt-9 flex flex-wrap gap-3 animate-rise [animation-delay:220ms]">
              {children ?? <HeroCtas />}
            </div>
          </div>
          <div className="page-media-frame lg:col-span-4 lg:col-start-9" data-reveal="mask">
            <ParallaxImage
              src={image.src}
              alt={image.alt}
              width={image.w}
              height={image.h}
              priority
              speed={0.12}
              className="aspect-[4/3] w-full lg:aspect-[4/5]"
              imageClassName="object-cover"
            />
            <p className="label-tech absolute bottom-4 left-4 bg-ink/75 px-3 py-2 text-foreground/80 backdrop-blur-sm">
              Green Sound / material autentic
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}

export function HeroCtas() {
  return (
    <>
      <Button asChild variant="hero" size="xl">
        <a href="#cerere-oferta">Cere ofertă pentru data ta</a>
      </Button>
      <Button asChild variant="stage" size="xl">
        <a href={business.phoneHref}>
          <Phone aria-hidden /> {business.phoneDisplay}
        </a>
      </Button>
    </>
  );
}

export function SectionHeading({
  eyebrow,
  title,
  intro,
  className = "",
}: {
  eyebrow: string;
  title: ReactNode;
  intro?: string;
  className?: string;
}) {
  return (
    <div className={`max-w-3xl ${className}`}>
      <p className="eyebrow">{eyebrow}</p>
      <h2 className="display-lg mt-5">{title}</h2>
      {intro && <p className="lead mt-5 opacity-80">{intro}</p>}
    </div>
  );
}

export function FaqList({
  faqs,
  tone = "stage",
}: {
  faqs: { q: string; a: string }[];
  tone?: "stage" | "paper";
}) {
  return (
    <Accordion type="single" collapsible className="w-full">
      {faqs.map((f, i) => (
        <AccordionItem
          key={f.q}
          value={`f-${i}`}
          className={tone === "paper" ? "border-paper-border" : "border-border"}
        >
          <AccordionTrigger className="py-6 text-left font-display text-lg font-semibold hover:no-underline md:text-xl">
            {f.q}
          </AccordionTrigger>
          <AccordionContent
            className={`pb-6 text-base leading-relaxed ${tone === "paper" ? "text-paper-muted" : "text-muted-foreground"}`}
          >
            {f.a}
          </AccordionContent>
        </AccordionItem>
      ))}
    </Accordion>
  );
}

export function ProcessSteps() {
  return (
    <ol className="grid gap-px overflow-hidden rounded-2xl border border-paper-border bg-paper-border md:grid-cols-4">
      {process.map((p, i) => (
        <li key={p.title} className="bg-paper p-7 md:p-8">
          <span className="serif-accent text-5xl text-paper-muted">0{i + 1}</span>
          <h3 className="mt-6 font-display text-xl font-semibold">{p.title}</h3>
          <p className="mt-3 text-sm leading-relaxed text-paper-muted">{p.text}</p>
        </li>
      ))}
    </ol>
  );
}

export function QuoteSection({
  title = "Spune-ne data. Restul îl construim împreună.",
  intro = "Completează câteva detalii și primești o ofertă personalizată. Cererea ajunge direct la noi pe WhatsApp sau email.",
  defaultEventType,
  defaultServices,
}: {
  title?: string;
  intro?: string;
  defaultEventType?: (typeof eventTypeOptions)[number] | undefined;
  defaultServices?: string[] | undefined;
}) {
  return (
    <section aria-labelledby="oferta-titlu" className="section surface-stage grain scroll-mt-20">
      <div className="container-site grid gap-14 lg:grid-cols-[0.8fr_1.2fr]">
        <div>
          <p className="eyebrow">Cere ofertă</p>
          <h2 id="oferta-titlu" className="display-lg mt-5">
            {title}
          </h2>
          <p className="lead mt-6 text-foreground/75">{intro}</p>
          <dl className="mt-10 grid gap-6 text-sm">
            <div>
              <dt className="text-muted-foreground">Telefon</dt>
              <dd className="mt-1 font-display text-2xl font-semibold">
                <a href={business.phoneHref} className="link-underline">
                  {business.phoneDisplay}
                </a>
              </dd>
            </div>
            <div>
              <dt className="text-muted-foreground">Email</dt>
              <dd className="mt-1 text-lg">
                <a href={`mailto:${business.email}`} className="link-underline">
                  {business.email}
                </a>
              </dd>
            </div>
            <div>
              <dt className="text-muted-foreground">Sediu</dt>
              <dd className="mt-1 text-lg">
                {business.address.street}, {business.address.city}
              </dd>
            </div>
          </dl>
        </div>
        <div className="relative rounded-2xl border border-border bg-card/60 p-6 backdrop-blur-sm md:p-10">
          <Suspense
            fallback={
              <div className="grid min-h-96 place-items-center" role="status">
                <p className="label-tech text-muted-foreground">Se pregătește formularul…</p>
              </div>
            }
          >
            <QuoteForm defaultEventType={defaultEventType} defaultServices={defaultServices} />
          </Suspense>
        </div>
      </div>
    </section>
  );
}

export function LinkCard({
  to,
  title,
  text,
  index,
}: {
  to: string;
  title: string;
  text: string;
  index?: number;
}) {
  return (
    <Link
      to={to}
      className="group flex h-full flex-col justify-between gap-8 border-t border-border py-7 transition-colors duration-300 hover:border-primary"
    >
      <div className="flex items-start justify-between gap-4">
        {index !== undefined && (
          <span className="serif-accent text-3xl text-primary">0{index + 1}</span>
        )}
        <ArrowUpRight
          className="ml-auto size-5 text-foreground/50 transition-all group-hover:-translate-y-0.5 group-hover:translate-x-0.5 group-hover:text-primary"
          aria-hidden
        />
      </div>
      <div>
        <h3 className="font-display text-xl font-semibold">{title}</h3>
        <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{text}</p>
      </div>
    </Link>
  );
}
