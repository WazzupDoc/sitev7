import { useEffect, useRef } from "react";

type Spring = { value: number; velocity: number; target: number };
type Magnet = {
  x: Spring;
  y: Spring;
  active: boolean;
};

const spring = (target = 0): Spring => ({ value: target, target, velocity: 0 });

/**
 * Decorative spring cursor with accurate pointer dot, inspired by editorial production sites.
 * - Native cursor is retained for accessibility.
 * - Only explicit data-magnetic controls are attracted, not every clickable card.
 * - CSS translate is independent of existing transform hover animations.
 * - Runs only for precise pointer + hover + no reduced motion.
 * - Direct DOM/RAF avoids a React render on every mouse movement.
 */
export function CustomCursor() {
  const dotRef = useRef<HTMLDivElement>(null);
  const ringRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const dot = dotRef.current;
    const ring = ringRef.current;
    if (!ring || !dot || typeof window === "undefined") return;

    const pointerMedia = window.matchMedia("(hover: hover) and (pointer: fine) and (min-width: 960px)");
    const motionMedia = window.matchMedia("(prefers-reduced-motion: reduce)");
    let enabled = false;
    let visible = false;
    let current: HTMLElement | null = null;
    let frame = 0;
    let cursorX = spring(-100);
    let cursorY = spring(-100);
    let seeded = false;
    const magnets = new Map<HTMLElement, Magnet>();

    const settle = (axis: Spring, stiffness: number, friction: number) => {
      axis.velocity = (axis.velocity + (axis.target - axis.value) * stiffness) * friction;
      axis.value += axis.velocity;
      if (Math.abs(axis.target - axis.value) < 0.03 && Math.abs(axis.velocity) < 0.03) {
        axis.value = axis.target;
        axis.velocity = 0;
      }
      return axis.velocity !== 0;
    };

    const tick = () => {
      frame = 0;
      const movingCursorX = settle(cursorX, 0.2, 0.66);
      const movingCursorY = settle(cursorY, 0.2, 0.66);
      let moving = movingCursorX || movingCursorY;
      ring.style.transform = `translate3d(${cursorX.value.toFixed(2)}px, ${cursorY.value.toFixed(2)}px, 0)`;

      for (const [element, magnet] of magnets) {
        if (!element.isConnected) {
          magnets.delete(element);
          if (current === element) current = null;
          continue;
        }
        const movingX = settle(magnet.x, 0.24, 0.65);
        const movingY = settle(magnet.y, 0.24, 0.65);
        element.style.translate = `${magnet.x.value.toFixed(2)}px ${magnet.y.value.toFixed(2)}px`;
        moving ||= movingX || movingY;
        if (!magnet.active && !movingX && !movingY) {
          element.style.removeProperty("translate");
          magnets.delete(element);
        }
      }
      if (moving) frame = requestAnimationFrame(tick);
    };
    const schedule = () => {
      if (!frame) frame = requestAnimationFrame(tick);
    };
    const release = () => {
      if (current) {
        const magnet = magnets.get(current);
        if (magnet) {
          magnet.active = false;
          magnet.x.target = 0;
          magnet.y.target = 0;
        }
        current = null;
      }
      ring.classList.remove("is-over-control");
      schedule();
    };

    const onMove = (event: PointerEvent) => {
      if (event.pointerType !== "mouse") return;
      if (!seeded) {
        seeded = true;
        cursorX = spring(event.clientX);
        cursorY = spring(event.clientY);
      }
      cursorX.target = event.clientX;
      cursorY.target = event.clientY;
      dot.style.transform = `translate3d(${event.clientX}px, ${event.clientY}px, 0)`;
      if (!visible) {
        visible = true;
        ring.classList.add("is-visible");
        dot.classList.add("is-visible");
      }
      const next = event.target instanceof Element
        ? event.target.closest<HTMLElement>("[data-magnetic]:not(:disabled)")
        : null;
      if (next !== current) {
        release();
        current = next;
        ring.classList.toggle("is-over-control", Boolean(current));
      }
      if (current) {
        let magnet = magnets.get(current);
        if (!magnet) {
          magnet = { x: spring(), y: spring(), active: true };
          magnets.set(current, magnet);
        }
        magnet.active = true;
        const rect = current.getBoundingClientRect();
        // The element has moved already, so subtract its previous displacement.
        const centerX = rect.left + rect.width / 2 - magnet.x.value;
        const centerY = rect.top + rect.height / 2 - magnet.y.value;
        magnet.x.target = Math.max(-9, Math.min(9, (event.clientX - centerX) * 0.13));
        magnet.y.target = Math.max(-7, Math.min(7, (event.clientY - centerY) * 0.13));
      }
      schedule();
    };
    const onLeave = () => {
      release();
      ring.classList.remove("is-visible");
      dot.classList.remove("is-visible");
      visible = false;
      seeded = false;
    };
    const teardown = () => {
      if (!enabled) return;
      enabled = false;
      document.removeEventListener("pointermove", onMove);
      document.removeEventListener("pointerleave", onLeave);
      window.removeEventListener("blur", onLeave);
      cancelAnimationFrame(frame);
      frame = 0;
      for (const element of magnets.keys()) element.style.removeProperty("translate");
      magnets.clear();
      current = null;
      visible = false;
      seeded = false;
      ring.classList.remove("is-visible", "is-over-control");
      dot.classList.remove("is-visible");
    };
    const sync = () => {
      if (!pointerMedia.matches || motionMedia.matches) {
        teardown();
        return;
      }
      if (enabled) return;
      enabled = true;
      document.addEventListener("pointermove", onMove, { passive: true });
      document.addEventListener("pointerleave", onLeave);
      window.addEventListener("blur", onLeave);
    };

    sync();
    pointerMedia.addEventListener("change", sync);
    motionMedia.addEventListener("change", sync);
    return () => {
      pointerMedia.removeEventListener("change", sync);
      motionMedia.removeEventListener("change", sync);
      teardown();
    };
  }, []);

  return (
    <>
      <div ref={ringRef} className="gs-magnetic-cursor" aria-hidden="true" />
      <div ref={dotRef} className="gs-magnetic-cursor-dot" aria-hidden="true" />
    </>
  );
}
