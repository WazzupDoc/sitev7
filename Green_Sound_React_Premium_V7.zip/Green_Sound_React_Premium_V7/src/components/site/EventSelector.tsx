import { Link } from "@tanstack/react-router";
import { ArrowRight, ArrowUpRight } from "lucide-react";
import { useState } from "react";
import { events, services } from "@/data/site";

/**
 * A production-art-directed event selector rather than a stock card grid.
 * Buttons are touch/keyboard accessible; the supporting image and copy
 * reflect only existing, verified categories in src/data/site.ts.
 */
export function EventSelector() {
  const [selectedIndex, setSelectedIndex] = useState(0);
  const selectedEvent = events[selectedIndex] ?? events[0]!;
  const suggested = selectedEvent.recommended
    .slice(0, 3)
    .map((entry) => services.find((service) => service.slug === entry.slug))
    .filter((service): service is (typeof services)[number] => Boolean(service));

  return (
    <div className="gs-event-editorial" aria-label="Explorează evenimentele Green Sound">
      <div className="gs-event-editorial__index">
        <div className="gs-event-editorial__index-head">
          <span className="label-tech text-foreground/55">Alege experiența</span>
          <span className="label-tech text-foreground/45">01 — 05</span>
        </div>
        <div className="gs-event-editorial__options" role="group" aria-label="Tipul evenimentului">
          {events.map((event, index) => (
            <button
              key={event.slug}
              type="button"
              onClick={() => setSelectedIndex(index)}
              onMouseEnter={() => {
                // On desktop, preview while hovering without navigating.
                // A touch click always sets the selection explicitly.
                if (window.matchMedia("(hover: hover) and (pointer: fine)").matches) {
                  setSelectedIndex(index);
                }
              }}
              onFocus={() => setSelectedIndex(index)}
              aria-pressed={selectedIndex === index}
              data-magnetic
              className="gs-event-editorial__option"
            >
              <span className="gs-event-editorial__number">{String(index + 1).padStart(2, "0")}</span>
              <span className="gs-event-editorial__label">{event.name}</span>
              <ArrowUpRight size={18} strokeWidth={1.65} aria-hidden="true" />
            </button>
          ))}
        </div>
        <p className="gs-event-editorial__helper">Alege un tip de eveniment pentru a descoperi serviciile potrivite.</p>
        <Link to="/evenimente" className="gs-event-editorial__all">
          Vezi toate evenimentele <ArrowRight size={16} aria-hidden="true" />
        </Link>
      </div>

      <div className="gs-event-editorial__stage" aria-label={`Prezentare ${selectedEvent.name}`}>
        <div data-parallax data-parallax-strength="32" className="gs-event-editorial__picture" key={selectedEvent.slug}>
          <img
            data-parallax-image
            src={selectedEvent.image.src}
            alt={selectedEvent.image.alt}
            width={selectedEvent.image.w}
            height={selectedEvent.image.h}
            decoding="async"
            loading="lazy"
          />
        </div>
        <div className="gs-event-editorial__stage-top" aria-hidden="true">
          <span>GREEN SOUND / EVENIMENTE</span>
          <span>{String(selectedIndex + 1).padStart(2, "0")} / {String(events.length).padStart(2, "0")}</span>
        </div>
        <div className="gs-event-editorial__stage-main">
          <div className="gs-event-editorial__eyebrow">PROPUNERE PENTRU EVENIMENTUL TĂU</div>
          <h3 key={`${selectedEvent.slug}-heading`} className="gs-event-editorial__stage-title">{selectedEvent.name}</h3>
          <p key={`${selectedEvent.slug}-copy`} className="gs-event-editorial__description">{selectedEvent.short}</p>
          <Link to="/evenimente/$slug" params={{ slug: selectedEvent.slug }} className="gs-event-editorial__discover">
            Descoperă experiența <ArrowUpRight size={18} aria-hidden="true" />
          </Link>
        </div>
        <div className="gs-event-editorial__suggested">
          <span className="gs-event-editorial__suggested-title">SERVICII POTRIVITE</span>
          <div className="gs-event-editorial__suggested-links">
            {suggested.map((service) => (
              <Link key={service.slug} to={`/${service.slug}`}>{service.name}</Link>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
