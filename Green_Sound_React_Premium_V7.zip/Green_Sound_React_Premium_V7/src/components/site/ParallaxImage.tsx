import type { ImgHTMLAttributes } from "react";
import { cn } from "@/lib/utils";

type Props = {
  src: string;
  alt: string;
  className?: string;
  imageClassName?: string;
  speed?: number;
  priority?: boolean;
  width?: number;
  height?: number;
  sizes?: ImgHTMLAttributes<HTMLImageElement>["sizes"];
};

/**
 * Cropped image with desktop-only, reduced-motion-safe Y parallax.
 * ParallaxMotion is mounted ONCE in the root and animates all wrappers,
 * avoiding one scroll/RAF/observer pair per picture.
 * The container must provide intrinsic aspect ratio via className or layout.
 */
export function ParallaxImage({
  src, alt, className, imageClassName, speed = 0.12,
  priority = false, width, height, sizes,
}: Props) {
  const strength = Math.round(Math.min(0.20, Math.max(0, speed)) * 200);
  return (
    <div
      data-parallax
      data-parallax-strength={strength}
      className={cn("relative overflow-hidden", className)}
    >
      <img
        data-parallax-image
        src={src}
        alt={alt}
        width={width}
        height={height}
        sizes={sizes}
        loading={priority ? "eager" : "lazy"}
        fetchPriority={priority ? "high" : "auto"}
        decoding="async"
        className={cn("absolute inset-0 size-full object-cover", imageClassName)}
      />
    </div>
  );
}
