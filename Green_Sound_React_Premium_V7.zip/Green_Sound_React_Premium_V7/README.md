# Green Sound Music Garden

https://greensoundmusic.com/
Pe baza acestui prompt te rog da-mi versiunea finala imbunatatita a site-ului

This project was built with [Lovable](https://lovable.dev).

**Live app**: https://green-sound-music-garden.lovable.app

## Build with Lovable

Continue developing this project in the [Lovable editor](https://lovable.dev/projects/6f92a315-49af-4e13-a684-28cea7b6cd37).

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: every change made in Lovable is committed straight to this repository.
- **Full ownership**: this code is yours. Push to `main` on GitHub and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```


## Premium Experience V5 — improvements (ChatGPT working copy)

This copy contains a real React component, **not** a detached HTML demo. It keeps the existing
TanStack Start / Tailwind app and the Figma Make enhancements intact.

- `src/components/site/EventSelector.tsx`: responsive, keyboard-friendly event selection with photo, short description, recommended service links and CTA.
- `src/styles.css`: art-directed event selector styling added to existing Tailwind entry, with no extra CSS request.
- `src/routes/index.tsx`: replaces plain event list with the interactive experience; changes secondary hero image priority to lazy/low.
- All media remains in `public/media/`; no paid themes/plugins added.

### Run locally

```bash
npm install
npm run dev
# in a separate terminal, after dependencies are installed
npm run build
npm run test
```

Important: still requires real browser QA, build validation, and production publishing approval.
The quote form continues opening WhatsApp/email composers rather than delivering messages server-side.
