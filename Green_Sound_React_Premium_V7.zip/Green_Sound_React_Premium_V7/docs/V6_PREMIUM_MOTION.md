# Green Sound Music — V6 Premium Motion / 2026-11-10

## Goal
Continue the **real React/TanStack/Figma Make** project from V5; do not replace with another standalone HTML mockup. This package keeps every service, route, photo, and business fact from V5.

## Inspiration and interpretation
- Plugged Live Shows: real-event storytelling and purposeful cinematic visual depth.
- Play X: clear film/production agency positioning and portfolio-first service discovery.
- Awwwards luxury/editorial galleries: carefully timed motion, large photographic scenes, restrained chrome and strong contrast.
- Original implementation: no copying any purchased template code, layout or proprietary images.

## Implemented
1. **MagneticCursor.tsx** — subtle spring-animated cursor ring and ~7–9px attraction on `data-magnetic` controls (main navigation, primary CTAs, event selector and gallery arrow controls); the native pointer is retained for accessibility.
2. **ParallaxMotion.tsx** — one passive scroll listener and batched animation frame for all `data-parallax` scenes; image-only translations while text remains fixed. Added to the hero scene, event-type photographic stage and people/behind-the-scenes photo.
3. **CSS** — safe image overscan so parallax does not reveal empty edges; spring movement uses the independent CSS `translate` property, preserving existing hover transforms.
4. **Progressive enhancement** — no motion when the user requests reduced motion; no parallax on screens under 768px; no magnetic cursor on touch devices or narrow screens; reduced-data support where the browser exposes it.
5. **No new dependencies**, no video autoplay, no mandatory loaders, no paid themes.

## Files modified
- `src/routes/__root.tsx` — global motion controllers.
- `src/routes/index.tsx` — hero and team photo parallax and CTA magnets.
- `src/components/site/SiteHeader.tsx` — main nav magnets.
- `src/components/site/EventSelector.tsx` — event option magnets and photographic parallax.
- `src/components/site/ProjectRail.tsx` — gallery control magnets.
- `src/styles.css` — motion styling.
- Added `src/components/site/MagneticCursor.tsx`, `ParallaxMotion.tsx`.

## Technical validation and remaining QA
- Verified that the project source files contain parseable TypeScript/TSX with the TypeScript transpiler.
- Checked local image assets under `public/media` and existing route tree.
- **Not verified:** end-to-end runtime, compiled production bundle, Lighthouse scores, browser animation smoothness, backend form delivery, live deployment.
- The environment did not have `node_modules`, so `npm run build` reported `vite: not found`. This is a missing local installation, *not* proof that the code compiles.

## How to run and test
```
npm install
npm run dev -- --host 0.0.0.0
```
Inspect at 390px, 768px and 1440px. Confirm that the header and CTA work, the gallery buttons still navigate, event categories switch on mouse/keyboard/touch, and animations disable in OS accessibility settings. Then run:
```
npm run build
npm run test
npm run lint
```
Fix real errors before merging/deploying.

## AI Studio Build — `Invalid argument`, `Ran for 0s`
These symptoms match reports on the Google AI Developers forum in October/November 2026, including projects that reject even a prompt asking for `OK`: https://discuss.ai.google.dev/t/google-ai-studio-build-agent-returns-invalid-argument-immediately-gemini-3-8-flash-ran-for-0s/186383

Safest recovery: **back up/export first**; test a trivial prompt; test a fresh empty project with the same account. If the old project fails but the new one responds, the failing state may belong to the old Build session. Only roll back a project version after a full backup. The exact root cause for a specific account is not known.
