# Green Sound Premium V5 — status and free online handoff

This package is the **real TanStack Start React project** from your Figma Make ZIP, not a static mockup.

## Actual source changes
- `src/components/site/EventSelector.tsx`: new premium photographic event explorer, desktop hover plus click/touch/keyboard selection, contextual real service links.
- `src/routes/index.tsx`: replaced generic event rows with EventSelector; low-priority loading for secondary desktop hero photo.
- `src/styles.css`: integrated responsive bespoke event explorer CSS, reduced-motion support, no extra animation package.
- `roadmap.md`: marked work completed vs. QA pending.

## Free online workflow (subject to Google limits)
1. Open https://aistudio.google.com/ and choose **Build**.
2. Open file explorer, use Add files / Upload Zip file if shown. Import `Green_Sound_React_Premium_V5.zip` (some UI versions may instead ask to import from GitHub).
3. Prompt: `This is an existing React 19 / TanStack Start project from Figma Make. Import and preserve all real business content, local files in public/media, routes and components. Check the build and fix environment-specific issues without replacing the project with a new generic landing page. Avoid adding paid services. Improve only the existing responsive interface, and provide a live mobile preview.`
4. Confirm that Build mode runs this framework/config; Figma/Lovable build config may require adaptation.
5. Share a preview **before** changing production DNS.

**Do not give any AI tool passwords, private keys or production credentials.**

## Local commands
`npm install`
`npm run dev`
`npm run build`
`npm run test`
`npm run lint`

## Testing completed here
- Parsed/transpiled all 92 TS/TSX source files with the TypeScript compiler API: no parser diagnostics.
- Verified replacement and preserved ProjectRail, ServiceIndex, VideoLite and QuoteSection in homepage source.
- Not tested: actual npm build/runtime/mobile browser. Dependencies were not installed in this working environment.
- Current quote form still opens WhatsApp/email composer, not a backend-submitted lead.
