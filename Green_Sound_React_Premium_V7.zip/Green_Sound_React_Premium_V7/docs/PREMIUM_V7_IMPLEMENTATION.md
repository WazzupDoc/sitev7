# Green Sound — V7 Motion Integration

This is an incremental upgrade of the **real React + TanStack Start application**, using the supplied creative/technical outline while correcting its edge cases. All content, routes and local public/media stay in place.

- `src/components/site/CustomCursor.tsx`: a genuine damped spring for the ring (rather than calling Lerp a spring), precise dot, delegated pointer tracking, hover attraction only on explicitly opted-in controls. RAF only runs while moving; native pointer stays visible.
- `src/components/site/ParallaxImage.tsx`: reusable image wrapper using source width/height and priority semantics, forwarding Y-motion responsibility to the existing shared `ParallaxMotion.tsx` controller.
- `src/components/site/blocks.tsx`: `PageHero` now uses the parallax image component, with actual Green Sound images; all page hero captions retained.
- `src/routes/__root.tsx`: mounts `CustomCursor` + the global `ParallaxMotion` exactly once.
- `src/styles.css`: overscan is a real 48px each side instead of a percentage that can reveal empty edges in shorter frames; no global `cursor: none`; touchscreen, reduced motion and reduced-data fallbacks.

## Differences from the submitted draft

1. Hiding the native pointer with `cursor:none !important` is not safe as a global rule; it affects input widgets and accessibility, and fails if JS is disabled. The decorative cursor supplements the native one.
2. The proposed `translate3d` on the ring overrides Tailwind transforms used for ring centering; CSS margin offsets avoid the conflict.
3. One perpetual RAF per cursor/parallax image is wasteful. V7 retains event delegation and uses a single, batched parallax controller, with RAF scheduled only after a scroll/resize/change.
4. `scale(1.15)` is not enough to guarantee coverage for every frame height; the image now has 48px overdraw on top/bottom and max offset of 40px.
5. Effects are enhancements, **not evidence of a finished Awwwards-level design**. The full redesign needs art direction, curated photography, layout and real browser QA.

## QA status

TypeScript/TSX parsing checked with installed TypeScript compiler. No dependency install/build has run successfully in this environment. Actual Vite production build, mobile/desktop rendering, accessibility validation, and Lighthouse must be completed after `npm install`. No production site was overwritten.

```bash
npm install
npm run build
npm run test
npm run lint
npm run dev
```
