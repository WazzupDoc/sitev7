# Green Sound Music — art direction

## Concept

**The craft behind the moment.** The site presents Green Sound as the coordinated team behind the music, sound, light and timing of a live event, not as a collection of unrelated suppliers.

## Visual system

- Deep blue-black stage surfaces (`#0A0F15`, `#101820`) alternate with soft chalk editorial chapters (`#F3F0E9`).
- Green (`#49B768`) is a functional signal for actions, active states and orientation, never a blanket glow.
- Hanken Grotesk remains the clear interface face. Bricolage Grotesque carries compact display text. Instrument Serif is used only for selected emotional phrases.
- Desktop uses a controlled 12-column rhythm and asymmetric media frames. Mobile uses its own editorial crops, horizontal rails and short labels rather than stacked desktop cards.
- Authentic Green Sound photography and YouTube posters are the visual proof. No invented case studies, stock performers, awards or testimonials.
- Stage cues, frame counters and hairline rules aid navigation. Equalizers, particles, music-note icons, permanent pulse effects and decorative marquees are rejected.

## Motion

- Opening sequence: concise text rise plus media mask reveal, all complete in about one second.
- Section reveals: 450–750 ms, opacity and small vertical offset only.
- Media hover: scale capped at 1.04, with no brightness flash or neon treatment.
- Gallery movement is user-controlled with swipe, keyboard and buttons.
- Route transitions are progressive enhancement and disabled for reduced motion.

## Reference principles adopted

- Plugged Live Shows: editorial restraint, generous negative space and the feeling of a bespoke live-production studio.
- Play X: clear commercial hierarchy, visible work archive and direct service navigation.
- Creative Spirit / Rezo Zero: precise typographic rhythm, quiet navigation and project-first framing.
- Offscreen Films: showreel-led proof, media state controls and useful work indexing.

## Principles rejected

- Mandatory loaders and scroll hijacking.
- Full-screen static photography with centered white copy.
- Paid-template compositions, copied typography lockups or proprietary assets.
- Oversized repeated headlines, six-card grids and gradients on every surface.
- Autoplay audio or heavy background video on mobile.

## Media plan

- Hero: `images.scena` as the main authored frame, `images.concert` as a secondary context crop and a real YouTube poster as a small production cue.
- Featured proof: real Ramada wedding video and verified Green Sound captions.
- Work archive: `mediaLibrary`, navigable by touch, keyboard and lightbox.
- Service and event navigation: existing service/event images only.
- Detail pages: existing videos and galleries, click-to-load via `VideoLite`.
