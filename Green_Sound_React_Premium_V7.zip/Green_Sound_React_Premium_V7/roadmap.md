# Green Sound Music — redesign roadmap

- [ ] Visual system v2: cinematic frames, reveal motion, page transitions, calmer type scale, no neon glow
- [ ] Homepage: cinematic hero reel, event switcher, service index, navigable project gallery, studio, tech rider, credits, process, FAQ, quote
- [ ] Shared: split page hero, media lightbox (video + photo, keyboard + swipe), reveal observer
- [ ] Portfolio: featured project + filterable navigable gallery with lightbox
- [ ] Service pages: signature block per service (crew, setlist, tech rider, effect package, studio tracklist, collage, cast)
- [ ] Missing routes: /contact, /despre-noi, /confidentialitate, /contact-green redirect, sitemap.xml
- [ ] Fix hydration mismatch (years counter, footer year)
- [ ] Verify build, mobile (390px) + desktop screenshots, routing test
- Blocked: creative brief file on GitHub is private/404 — worked from the pasted prompt
- Blocked: publishing — waits on owner approval


## Premium Experience V5 (this source copy)
- [x] Event type selection component with native buttons and no paid dependencies
- [x] Dynamic photos and factual contextual service links from existing source data
- [x] Mobile category rail, keyboard focus, reduced-motion styling
- [x] Lower priority for the secondary desktop hero image
- [ ] Full npm build, lint and test (not available in this container without dependencies)
- [ ] Test interaction in real mobile browser
- [ ] Deploy preview from actual React project; protect production domain
